﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

// Name: Robert Jacobs 30018755
// Date:
// Project: Drone application to record and store drone names and information.
// Description: The user uses the text box to input the Engine, range, Accessories and Price information into the application.
// after the input the user can click a button to add the information to an array for storage.

namespace AT1._2Programming2_DroneStorage
{
    public partial class MyDronesForm : Form
    {
        
        public MyDronesForm()
        {
            InitializeComponent();
        }

        
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void addButton_Click(object sender, EventArgs e)
        {
            addTextBox();
        }
        public void addTextBox()
        {
            Drone droneClass = new Drone();

            droneClass.gsEngine = engineTextBox.Text;
            droneClass.gsRange = rangeTextBox.Text;
            droneClass.gsAccessories = accessoriesTextBox.Text;
            droneClass.gsPrice = priceTextBox.Text;
            droneArrayTextBox.Text = engineTextBox.Text + rangeTextBox.Text + accessoriesTextBox.Text + priceTextBox.Text;
            droneDisplayBox.Text = droneArrayTextBox.Text;

            //Drone droneClass = new Drone();
            droneClass.droneCreateArray();

        }

    }
}
