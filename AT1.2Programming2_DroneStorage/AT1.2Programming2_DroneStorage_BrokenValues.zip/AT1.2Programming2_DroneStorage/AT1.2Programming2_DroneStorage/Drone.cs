﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AT1._2Programming2_DroneStorage
{
    class Drone
    {
        private static int max = 10;
        private string[] droneArray = new string[max];
        private string engineConfiguation;
        private string range;
        private string accessories;
        private string price;
        MyDronesForm mdf = new MyDronesForm();

        public string gsEngine
        {
           
            get { return engineConfiguation;}
            set { engineConfiguation = gsEngine; }

        }

        public string gsRange
        {
            get { return range; }
            set { range = gsRange; }

        }
        public string gsAccessories
        {
            get { return accessories; }
            set { accessories = gsAccessories; }

        }
        public string gsPrice
        {
            get { return price; }
            set { price = gsPrice; }

        }

        public void droneCreateArray()
        {
            

                for (int i = 0; i < 10; i++)
                {
                MyDronesForm mdf = new MyDronesForm();

                droneArray[i] = gsEngine + gsRange + gsAccessories + gsPrice;
                if (!(droneArray[i] == null))
                {
                    mdf.droneDisplayBox.Items.Add(droneArray[i]);

                    droneClearTextBox();
                    
                }
                else
                {
                    MessageBox.Show("Error Message", "droneArray[i] Came back as Null");
                    return;
                }
                }
           
        }
        //public void droneAddTextBox()
        //{
            
        //    engineConfiguation = mdf.engineTextBox.Text;
        //    range = mdf.rangeTextBox.Text;
        //    accessories = mdf.accessoriesTextBox.Text;
        //    price = mdf.priceTextBox.Text;
        //    mdf.droneArrayTextBox.Text = mdf.engineTextBox.Text + mdf.rangeTextBox.Text + mdf.accessoriesTextBox.Text + mdf.priceTextBox.Text;
        //}
        public void droneClearTextBox()
        {

            mdf.droneArrayTextBox.Clear();
            mdf.engineTextBox.Clear();
            mdf.rangeTextBox.Clear();
            mdf.accessoriesTextBox.Clear();
            mdf.priceTextBox.Clear();
        }
        public void clearListBox()
        {

            mdf.droneDisplayBox.Items.Clear();
        }


    }
}
